"""Adapters for credential auditor."""
