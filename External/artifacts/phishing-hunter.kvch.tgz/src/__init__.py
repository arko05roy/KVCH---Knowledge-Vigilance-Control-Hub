"""Phishing Hunter package."""
