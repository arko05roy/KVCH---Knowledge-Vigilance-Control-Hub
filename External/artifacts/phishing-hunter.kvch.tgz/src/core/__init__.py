"""Core detection logic."""
