"""Core threat hunter engine."""
