"""VPN Crypto Analyzer package."""
