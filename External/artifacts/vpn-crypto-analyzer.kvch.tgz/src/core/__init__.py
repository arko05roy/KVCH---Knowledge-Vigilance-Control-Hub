"""Core analyzer engine."""
